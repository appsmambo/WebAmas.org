Artificial-Reason
=================

Artificial Reason Template
