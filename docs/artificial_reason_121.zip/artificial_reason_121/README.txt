Artificial Reason
=================

How install and Configure
-------------------------

Documentation and installation instructions are in the documentation folder. Open the index.html file and follow the instructions.